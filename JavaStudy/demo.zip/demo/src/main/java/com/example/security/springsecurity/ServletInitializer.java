package com.example.security.springsecurity;

public class ServletInitializer {

}
